#ifndef __sntp_lwip2_h__
#define __sntp_lwip2_h__

extern "C" {

bool sntp_set_timezone_in_seconds(sint32 timezone);

}

#endif
